import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class DatabaseAccess {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("Hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session s = sf.openSession();
		Transaction tx = s.beginTransaction();
		
		
		// ===== INSERT ===== //
		Employee emp = new Employee();
		emp.setId(1);
		emp.setName("Timo");
		emp.setMobile(112233);
		emp.setEmail("timo@gmx.de");
		
		s.save(emp);
		
		s.flush(); 		
		tx.commit();
		s.close();
		
		
		/*
		// ===== SELECT ===== //
		//Employee emp = (Employee) s.load(Employee.class, new Integer(1));		// table row must exist
		Employee emp = (Employee) s.get(Employee.class, new Integer(1));		// if table row doesn't exist --> returns a NULL-Pointer

		System.out.println(emp.getId());
		System.out.println(emp.getName());
		System.out.println(emp.getMobile());
		System.out.println(emp.getEmail());
		s.close();
		*/

		/*
		// ===== UPDATE ===== //
		Employee emp = (Employee) s.get(Employee.class, new Integer(1));

		emp.setId(1);
		emp.setName("Daniel");
		emp.setMobile(2468);
		emp.setEmail("daniel@gmx.de");

		//s.update(emp);				// table row must exist
		s.saveOrUpdate(emp);			// if table row doesn't exist --> inserts a new data set
		
		s.flush(); 		
		tx.commit();
		s.close();
		*/
		
		/*
		// ===== DELETE ===== //
		Employee emp = (Employee) s.get(Employee.class, new Integer(1));

		s.delete(emp);

		s.flush(); 		
		tx.commit();
		s.close();
		*/
		
		// select * from employee;
		// drop table employee;
	}
}
